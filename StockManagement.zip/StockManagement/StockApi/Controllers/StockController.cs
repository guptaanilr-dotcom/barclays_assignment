using Microsoft.AspNetCore.Mvc;
using StockRepository;
using log4net;
using StockDomain;

namespace StockApi.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    public class StockController : ControllerBase
    {
        private readonly IStockService _stockService;
        private static readonly ILog _log = LogManager.GetLogger(typeof(StockController));

        public StockController(IStockService stockService)
        {
            if (stockService == null) throw new ArgumentNullException("stockService");
            _stockService = stockService;
        }

        [HttpGet("tickers")]
        //[CacheFilter(TimeDuration = 100)]
        [ResponseCache(Duration = 3600)]
        public IActionResult GetAllTickers()
        {
            var tickers = new List<Stock>();
            try
            {
                var tickerList = _stockService.GetAllTickers();

                if (tickerList != null && tickerList.Any())
                    tickers = tickerList.Cast<Stock>().ToList();
                else if (tickerList == null)
                    return NotFound();                
            }
            catch (Exception ex)
            {
                _log.ErrorFormat("Error : {0}", ex.Message);
            }
            return Ok(tickers);
        }

        [HttpGet("{ticker}")]
        public IActionResult GetTickerDetails(string ticker)
        {
            var tickerDetails = new Stock();

            try
            {
                tickerDetails = _stockService.GetTickerDetails(ticker);

                if (tickerDetails == null)
                    return NotFound();
            }
            catch (Exception ex)
            {
                _log.ErrorFormat("Error : {0}", ex.Message);
            }
            return Ok(tickerDetails);
        }

        [HttpGet("{ticker}/buy")]
        public IActionResult GetBuyingOption(string ticker, [FromQuery] decimal budget)
        {
            var tickerDetails = new Stock();

            try
            {
                tickerDetails = _stockService.GetBuyingOption(ticker, budget);

                if (tickerDetails == null)
                    return NotFound();
            }
            catch (Exception ex)
            {
                _log.ErrorFormat("Error : {0}", ex.Message);
            }
            return Ok(tickerDetails);
        }
    }
}