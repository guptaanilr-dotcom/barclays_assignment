﻿using StockDomain;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using Microsoft.Extensions.Caching.Memory;

namespace StockRepository
{
    public class StockDbService : IStockService
    {
        private readonly IMemoryCache _memoryCache;
        public string cacheKey = "tickers";

        public StockDbService(IMemoryCache memoryCache)
        {
            _memoryCache = memoryCache;
        }

        public IEnumerable<Stock> GetAllTickers()
        {
            throw new NotImplementedException();
        }

        public Stock GetBuyingOption(string ticker, decimal budget)
        {
            throw new NotImplementedException();
        }

        public Stock GetTickerDetails(string ticker)
        {
            throw new NotImplementedException();
        }
    }
}
