﻿using StockDomain;
using System.Collections.Generic;

namespace StockRepository
{
    public interface IStockService
    {
        IEnumerable<Stock> GetAllTickers();
        Stock GetTickerDetails(string ticker);
        Stock GetBuyingOption(string ticker, decimal budget);
    }
}
