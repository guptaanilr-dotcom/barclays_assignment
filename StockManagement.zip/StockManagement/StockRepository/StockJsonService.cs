﻿using StockDomain;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using Microsoft.Extensions.Caching.Memory;

namespace StockRepository
{
    public class StockJsonService : IStockService
    {
        private const string _stocksJsonFileName = "stocks.json";
        private readonly IMemoryCache _memoryCache;
        public string cacheKey = "tickers";

        public StockJsonService(IMemoryCache memoryCache)
        {
            _memoryCache = memoryCache;
        }


        private readonly JsonSerializerOptions _options = new()
        {
            PropertyNameCaseInsensitive = true
        };

        public IEnumerable<Stock> GetAllTickers()
        {
            List<Stock> tickers;

            if (!_memoryCache.TryGetValue(cacheKey, out tickers))
            {
                tickers = ReadTickersJsonFile(); 

                _memoryCache.Set(cacheKey, tickers,
                    new MemoryCacheEntryOptions()
                    .SetAbsoluteExpiration(TimeSpan.FromSeconds(20)));
            }
            return tickers;
        }

        public Stock GetTickerDetails(string ticker)
        {
            return ReadTickersJsonFile().Where(x => x.Ticker == ticker).SingleOrDefault();
        }

        public Stock GetBuyingOption(string ticker, decimal budget)
        {
            return ReadTickersJsonFile()
                .Where(x => x.Ticker == ticker
                        && x.Close <= budget).SingleOrDefault();
        }

        private List<Stock> ReadTickersJsonFile()
        {
            List<Stock> tickers = new List<Stock>();
            if (File.Exists(_stocksJsonFileName))
            {
                var json = File.ReadAllText(_stocksJsonFileName);
                return tickers = JsonSerializer.Deserialize<List<Stock>>(json, _options);
            }
            return tickers;
        }
    }
}
