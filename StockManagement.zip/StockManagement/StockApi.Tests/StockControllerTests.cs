﻿using Microsoft.AspNetCore.Mvc;
using Moq;
using StockApi.Controllers;
using StockDomain;
using StockRepository;
using System.Dynamic;
using System.Text.Json;

namespace StockApi.Tests
{
    public class StockControllerTests
    {
        private const string _stocksJsonFileName = "stockstestdata.json";
        private List<Stock>? sessionTickers;
        public StockControllerTests()
        {
            GetTickersTestJsonData();
        }

        [Fact]
        public void GetAllTickers_ShouldReturnListOfTickers()
        {
            // Arrange
            var _stockServiceMock = new Mock<IStockService>();
            _stockServiceMock.Setup(repo => repo.GetAllTickers()).Returns(sessionTickers);
            var controller = new StockController(_stockServiceMock.Object);

            // Act
            var result = controller.GetAllTickers() as OkObjectResult;

            // Assert
            var tickers = Assert.IsType<List<Stock>>(result?.Value);
            Assert.Equal(3, tickers.Count);
        }

        [Fact]
        public void GetTickerDetails_ShouldReturnCorrectDetailsForAAPL()
        {
            // Arrange
            var targetTicker = "AAPL";
            var _stockServiceMock = new Mock<IStockService>();
            _stockServiceMock.Setup(repo => repo.GetTickerDetails(targetTicker)).Returns(sessionTickers.SingleOrDefault(x => x.Ticker == targetTicker));
            var controller = new StockController(_stockServiceMock.Object);

            // Act
            var result = controller.GetTickerDetails(targetTicker) as OkObjectResult;

            // Assert
            dynamic stock = Assert.IsType<Stock> (result?.Value);
            Assert.NotNull(stock);
            Assert.Equal("AAPL", (string)stock.Ticker);
            Assert.Equal(198.15m, (decimal)stock.Open);
            Assert.Equal(202.30m, (decimal)stock.Close);
        }

        [Fact]
        public void GetBuyingOption_ShouldReturnNumberOfSharesForBudget()
        {
            // Arrange
            var targetTicker = "AAPL";
            var targetbudget = 1000;
            var stockService = new Mock<IStockService>();
            stockService.Setup(repo => repo.GetBuyingOption(targetTicker, targetbudget)).Returns(sessionTickers.SingleOrDefault(x => x.Ticker == targetTicker && x.Close <= targetbudget));
            var controller = new StockController(stockService.Object);

            // Act
            var result = controller.GetBuyingOption(targetTicker, targetbudget) as OkObjectResult;

            // Assert
            dynamic stock = Assert.IsType<Stock>(result?.Value);
            dynamic response = new ExpandoObject();
            response.Ticker = stock.Ticker;
            response.Budget = targetbudget;
            response.Shares = (int)targetbudget / stock.Close;

            Assert.NotNull(stock);
            Assert.Equal("AAPL", (string)response.Ticker);
            Assert.Equal(1000, (decimal)response.Budget);
            Assert.Equal(4, (int)response.Shares); // 1000 / 202.30 ≈ 4
        }

        [Fact]
        public void GetTickerDetails_ShouldReturnNoTickerFoundForPPAL()
        {
            // Arrange
            var targetTicker = "PPAL";
            var _stockServiceMock = new Mock<IStockService>();
            _stockServiceMock.Setup(repo => repo.GetTickerDetails(targetTicker)).Returns(sessionTickers.SingleOrDefault(x => x.Ticker == targetTicker));
            var controller = new StockController(_stockServiceMock.Object);

            // Act
            var result = controller.GetTickerDetails(targetTicker) as OkObjectResult;

            // Assert
            Assert.Null(result);
        }

        private void GetTickersTestJsonData()
        {
            JsonSerializerOptions _options = new()
            {
                PropertyNameCaseInsensitive = true
            };

            List<Stock>? tickers = new List<Stock>();
            if (File.Exists(_stocksJsonFileName))
            {
                var json = File.ReadAllText(_stocksJsonFileName);
                sessionTickers = JsonSerializer.Deserialize<List<Stock>>(json, _options);
            };
        }
    }
}